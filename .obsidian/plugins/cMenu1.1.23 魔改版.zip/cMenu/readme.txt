cmenu 1.1.22 魔改版 by cuman
cmenu 原版地址 https://github.com/chetachiezikeuzor/cMenu-Plugin
此插件是在cMenu1.1.2 跟随悬浮效果 基础上魔改而成，增加了 固定和跟随选项设置

- 增加位置固定和跟随选项。
- 增加了 cmenu 风格 tiny样式，更紧凑。
- 修复了 插件跟随位置判断
- 修复了悬浮效果在边界触发溢出的问题
- 修复了按钮超过一行，背景框不对应问题。

此插件建议搭配 蚕子大神的 zh增强编辑插件使用。

插件已内置 remixicon 字体文件。图标代码可以参考 https://remixicon.com/

后续更新请关注
https://kknwfe6755.feishu.cn/docs/doccnQpRTqGYqMT3GAKka5IRnMf?from=from_copylink